﻿// API KEY: AIzaSyC4WmIN47kMB1HqbQkBrN4xommVV96h8_A //

// const mapBox = document.getElementById("map");

// function addMap() {
//     mapBox.innerHTML +=
//     `
//     <p>${Model.Address}</p>
//     `
// }
// addMap();