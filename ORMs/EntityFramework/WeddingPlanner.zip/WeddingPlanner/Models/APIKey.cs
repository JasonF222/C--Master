namespace WeddingPlanner.Models;

public class APIKey
{
    public string MyAPIKey = "AIzaSyCcvHrzdSMIkq7fb5sBDMvEMQ9Dpn0KLlI";
}