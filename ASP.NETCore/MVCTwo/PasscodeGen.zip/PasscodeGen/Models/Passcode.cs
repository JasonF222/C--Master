namespace PasscodeGen.Models;

public class Passcode
{
    public string NewPass { get; set; } = null!;
}