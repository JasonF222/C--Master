﻿// See https://aka.ms/new-console-template for more information
// Console.WriteLine("Hello, World!");


// RANDOM ARRAY //


static int[] RandomArray()
{
    int[] arrayOfNums = new int[10];
    int total = 0;
    int minVal = arrayOfNums[0];
    int maxVal = arrayOfNums[0];
    Random rand = new Random();
    for(int i = 0; i < arrayOfNums.Length; i++)
    {

        arrayOfNums[i] = rand.Next(5,26);
        minVal = arrayOfNums[0];
    }
    foreach(int value in arrayOfNums)
    {
        total += value;
        Console.Write(value + " ");
        if(value < minVal)
        {
            minVal = value;
        }
        else if(value > maxVal)
        {
            maxVal = value;
        }
    }
    Console.WriteLine($"Total: {total}");
    Console.WriteLine($"Min Value: {minVal}");
    Console.WriteLine($"Max Value: {maxVal}");
    Console.WriteLine(" ");
    Console.WriteLine(" ");
    return arrayOfNums;
}

RandomArray();



// COIN FLIP //


// static void TossCoin()
// {
//     Random rand = new Random();
//     Console.WriteLine("Tossing a Coin!"); 
//     if (rand.Next(1,3) == 1)
//     {
//         Console.WriteLine("Heads!");
//     }
//     else Console.WriteLine("Tails!");
//         Console.WriteLine(" ");
// }
// TossCoin();


// NAMES //


// static List<string> Names()
// {
//     List<string> listNames = new List<string>();
//     listNames.Add("Todd");
//     listNames.Add("Tiffani");
//     listNames.Add("Charlie");
//     listNames.Add("Geneva");
//     listNames.Add("Sydney");
//     List<string> longNames = new List<string>();
//     foreach(string name in listNames)
//     {
//         if(name.Length > 5) 
//         {
//             longNames.Add(name);
//             Console.WriteLine(name);
//         }
//     }
//     return longNames;
// }
// Names();
