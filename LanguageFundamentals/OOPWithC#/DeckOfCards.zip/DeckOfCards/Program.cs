﻿// Card newCard = new Card("Clubs", 12);
// newCard.Print();

Deck deckOfCards = new Deck();
deckOfCards.Reset();

// Player newPlayer = new Player("Jackson");
