﻿// Card newCard = new Card("Clubs", 12);
// newCard.Print();
// Deck deckOfCards = new Deck();
// Player newPlayer = new Player("Jackson");
// deckOfCards.Shuffle();
// deckOfCards.Deal();


// newPlayer.Draw(deckOfCards);
// newPlayer.Draw(deckOfCards);
// newPlayer.Draw(deckOfCards);
// newPlayer.Draw(deckOfCards);
// newPlayer.Draw(deckOfCards);

// newPlayer.Discard(2);
// newPlayer.Discard(5);
// newPlayer.ShowHand();
