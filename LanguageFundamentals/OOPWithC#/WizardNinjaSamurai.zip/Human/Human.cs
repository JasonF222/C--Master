public class Human
{
    // Properties for Human //
    public string Name;
    public int Strength;
    public int Intelligence;
    public int Dexterity;
    public int Health;

    // Constructor to take a value to set Name, and default set remaining values  //
    public Human(string name)
    {
        Name = name;
        Strength = 3;
        Intelligence = 3;
        Dexterity = 3;
        Health = 100;
    }

    // Constructor to assign custom values to all fields //
    public  Human(string name, int valStr, int valInt, int valDex, int valHP)
    {
        Name = name;
        Strength = valStr;
        Intelligence = valInt;
        Dexterity = valDex;
        Health = valHP;
    }

    
    

    // Attack Method //
    public virtual int Attack(Human target)
    {
        int dmg = Strength * 3;
        target.Health -= dmg;
        Console.WriteLine($" {Name} attacked {target.Name} for {dmg} damage!");
        return target.Health;
    }



}