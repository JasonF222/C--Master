﻿Human newWarrior = new Human("Geralt", 5, 5, 5, 150); 

Human newTarget = new Human("Taz", 6, 4, 3, 100);

Wizard newWizard = new Wizard("Gandalf");

Ninja newNinja = new Ninja("Tetsudo");

Samurai newSamurai = new Samurai("Oni");

// newWarrior.Attack(newTarget);
// newWizard.Attack(newTarget);
// newWizard.Heal(newWarrior);
// newNinja.Attack(newTarget);
// newNinja.Steal(newTarget);
// newSamurai.Attack(newTarget);
// newSamurai.Meditate();
