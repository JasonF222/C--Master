﻿Human newWarrior = new Human("Geralt", 5, 5, 5, 150); 
Human bob = new Human("Bob");
Human jane = new Human("Jane", 5, 4, 4, 150);

Human newTarget = new Human("Taz", 6, 4, 3, 100);

Wizard newWizard = new Wizard("Gandalf");

Ninja newNinja = new Ninja("Tetsudo");

Samurai newSamurai = new Samurai("Jack");


while(newTarget.Health > 0)
{ 
// newWarrior.Attack(newTarget);
// newWizard.Attack(newTarget);
// newWizard.Heal(newWarrior);
// newNinja.Attack(newTarget);
// newNinja.Steal(newTarget);
newSamurai.Attack(newTarget);
// bob.Attack(newTarget);
}
newSamurai.Meditate();
