public class Samurai : Human
{
    private int Fortitude;
    public Samurai(string name) : base(name)
    {
        Health = 200;
        Fortitude = 5;
    }

    public override int Attack(Human target)
    {
        base.Attack(target);
        if (target.Health < 50)
        {
            target.Health = 0;
            Console.WriteLine($"{Name} executed {target.Name}!");
        }
        return target.Health;
    }

    // Meditate Method //
    public int Meditate()
    {
        Health = Fortitude * 10;
        // Health = 200;
        Console.WriteLine($"{Name} meditates, healing for {Health} health!");
        return Health;
    }
}