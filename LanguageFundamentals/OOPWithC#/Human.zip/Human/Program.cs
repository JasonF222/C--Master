﻿Human newWarrior = new Human("Jack", 5, 5, 5, 150); 
Human newTarget = new Human("Taz", 6, 4, 3, 100);

newWarrior.Attack(newTarget);