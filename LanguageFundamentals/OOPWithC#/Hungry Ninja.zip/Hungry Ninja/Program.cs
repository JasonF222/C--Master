﻿Buffet buffet = new Buffet();

Ninja newNinja = new Ninja();

newNinja.Eat(buffet.Serve());
newNinja.Eat(buffet.Serve());
newNinja.Eat(buffet.Serve());
newNinja.Eat(buffet.Serve());
newNinja.Eat(buffet.Serve());